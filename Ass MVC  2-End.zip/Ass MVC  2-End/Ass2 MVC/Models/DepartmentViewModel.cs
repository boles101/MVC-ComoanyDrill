﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Ass2_MVC.Models
{
    public class DepartmentViewModel
    {
        public int Id { get; set; }
        [Required]
        public string Code { get; set; }

        [Required(ErrorMessage = "Error the department name is a required field")]
        [MinLength(1, ErrorMessage = "Name is less than minimum length")]
        public string DateOfCreation { get; set; } = DateTime.Now.ToString();

        public string Name { get; set; }
    }
}
