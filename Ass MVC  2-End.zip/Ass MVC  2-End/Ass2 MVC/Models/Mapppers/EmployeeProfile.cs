﻿using Ass.DAL.Entities;
using AutoMapper;

namespace Ass2_MVC.Models.Mapppers
{
    public class EmployeeProfile:Profile
    {
        public EmployeeProfile()
        {
            CreateMap<Employee,EmployeeViewModel>().ReverseMap();
        }
    }
}
