﻿using Ass.DAL.Entities;
using AutoMapper;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace Ass2_MVC.Models.Mapppers
{
    public class DepartmentProfile: Profile
    {
        public DepartmentProfile()
        {
            CreateMap<Department, DepartmentViewModel>().ReverseMap();
        }
    }
}
