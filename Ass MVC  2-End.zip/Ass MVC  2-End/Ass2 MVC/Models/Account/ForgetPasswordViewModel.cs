﻿using System.ComponentModel.DataAnnotations;

namespace Ass2_MVC.Models.Account
{
    public class ForgetPasswordViewModel
    {
        [Required(ErrorMessage = "Email is Required")]
        [EmailAddress(ErrorMessage = "Email is Invalid")]
        public string Email { get; set; }

    }
}
