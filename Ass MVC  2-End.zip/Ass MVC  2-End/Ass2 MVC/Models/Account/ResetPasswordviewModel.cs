﻿using System.ComponentModel.DataAnnotations;

namespace Ass2_MVC.Models.Account
{
    public class ResetPasswordviewModel
    {
        [Required(ErrorMessage = "Password is Required")]
        [MinLength(5, ErrorMessage = "Password is less than 5 chars")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password is Required")]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }

        public string Email { get; set; }

        public string Token{ get; set; }

    }
}
