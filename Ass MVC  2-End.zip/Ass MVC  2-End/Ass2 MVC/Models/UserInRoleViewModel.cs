﻿namespace Ass2_MVC.Models
{
    public class UserInRoleViewModel
    {
        public string UserId{ get; set; }
        public string UserName{ get; set; }

        public bool IsSelected{ get; set; }

    }
}
