﻿using Ass.BLL.Interfaces;
using Ass.BLL.Repositories;
using Ass.DAL.Entities;
using Ass2_MVC.Models;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Ass2_MVC.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly IUnitOfWork unitOfWork;

        //private readonly IDepartmentRepository departmentRepository;
        private readonly IMapper mapper;

        public DepartmentController(IUnitOfWork unitOfWork,IMapper mapper )
        {
            //this.departmentRepository = departmentRepository;
            this.unitOfWork = unitOfWork;
            this.mapper = mapper;
        }
        public async Task<IActionResult> Index()
        {
            var departments = await this.unitOfWork.DepartmentRepository.GetAll();
            var MappedDepartments = this.mapper.Map<IEnumerable<DepartmentViewModel>>(departments);

            return View(MappedDepartments);
        }

        [HttpGet]
        public IActionResult Create()  // made for the create new department button 
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(DepartmentViewModel departmentViewModel )  // the actual creation page
        {
            if(ModelState.IsValid) 
            {
                var MappedDepartments = this.mapper.Map<Department>(departmentViewModel);
                await this.unitOfWork.DepartmentRepository.Add(MappedDepartments);
                return RedirectToAction("Index");
            }
            return View(departmentViewModel);
        }
        [HttpGet]
        public async Task<IActionResult> Details(int? id) 
        {
            if(id== null)
                return NotFound();
            var department = await this.unitOfWork.DepartmentRepository.Get(id);
            var MappedDepartments = this.mapper.Map<DepartmentViewModel>(department);

            if(department == null)
                return NotFound();

            return View(MappedDepartments);
        }

        public async Task<IActionResult> Update (int? id)
        {
            if (id == null)
                return NotFound();
            var department = await this.unitOfWork.DepartmentRepository.Get(id);
            var MappedDepartments = this.mapper.Map<DepartmentViewModel>(department);

            if (department == null)
                return NotFound();

            return View(MappedDepartments);
        }

        [HttpPost]
        public async Task<IActionResult> Update(int? id,DepartmentViewModel departmentViewModel)
        {
            if(id != departmentViewModel.Id)
                return NotFound ();   
            if (ModelState.IsValid)
            {
                try
                {
                    var MappedDepartments = this.mapper.Map<Department>(departmentViewModel);
                   await this.unitOfWork.DepartmentRepository.Update(MappedDepartments);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    return View(departmentViewModel);
                }
            }
            return View(departmentViewModel);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();
            var department =  await this.unitOfWork.DepartmentRepository.Get(id);

            if (department == null)
                return NotFound();
            await this.unitOfWork.DepartmentRepository.Delete(department);

            return RedirectToAction("Index");
        }



    }
}
