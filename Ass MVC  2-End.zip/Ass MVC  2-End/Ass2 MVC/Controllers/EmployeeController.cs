﻿using Ass.BLL.Interfaces;
using Ass.DAL.Entities;
using Ass2_MVC.Helper;
using Ass2_MVC.Models;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Ass2_MVC.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IUnitOfWork unitOfWork;

        //private readonly IEmployeeRepository employeeRepository;
        //private readonly IDepartmentRepository departmentRepository;
        private readonly IMapper mapper;

        public EmployeeController(/*IEmployeeRepository employeeRepository*/ 
                                 //,IDepartmentRepository departmentRepository
                                 IUnitOfWork UnitOfWork
                                 ,IMapper mapper)
        {
            //this.employeeRepository = employeeRepository;
            //this.departmentRepository = departmentRepository;
            unitOfWork = UnitOfWork;
            this.mapper = mapper;
        }

        #region Index
        public async Task<IActionResult> Index(string SearchValue = "")
        {

            IEnumerable<Employee> employees;
            if (string.IsNullOrEmpty(SearchValue))
            {
                employees = await this.unitOfWork.EmployeeRepository.GetAll();   // get all if search value is empty (default)
            }
            else
            {
               employees = await this.unitOfWork.EmployeeRepository.Search(SearchValue);
            }
            var MappedEmployees = this.mapper.Map<IEnumerable<EmployeeViewModel>>(employees);
            return View(MappedEmployees);


        }

        #endregion

        #region Create
        public async Task<IActionResult> Create()  
        {
            ViewBag.departments = await this.unitOfWork.DepartmentRepository.GetAll();
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(EmployeeViewModel employeeViewModel)
        {
            

            if (ModelState.IsValid)
            {
                //var MappedEmployee = new Employee()
                //{
                //    Id = employee.Id,
                //    Name = employee.Name,
                //    Age = employee.Age,
                //    Address = employee.Address,
                //    Salary = employee.Salary,
                //    IsActive = employee.IsActive,
                //    Email = employee.Email, 
                //    PhoneNumber = employee.PhoneNumber,
                //    HireDate= employee.HireDate,
                //    DepartmentId = employee.DepartmentId
                //};

                employeeViewModel.ImageUrl = DocumentSettings.UploadFile(employeeViewModel.Image, "Images");
                var MappedEmployee = this.mapper.Map<Employee>(employeeViewModel);
                await this.unitOfWork.EmployeeRepository.Add(MappedEmployee);
                return RedirectToAction("Index");
            }
            return View(employeeViewModel);

        }

        #endregion

        #region Details
        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();
            var employee = await this.unitOfWork.EmployeeRepository.Get(id);
            var MappedEmployee = this.mapper.Map<EmployeeViewModel>(employee);
            var DepartmentName = await this.unitOfWork.EmployeeRepository.GetDepartmentByEmployeeID(id);

            //employee.Department.Name = DepartmentName; 

            if (employee == null)
                return NotFound();

            return View(MappedEmployee);
        }
        #endregion

        #region Update
        public async Task<IActionResult> Update(int? id)
        {
            if (id == null)
                return NotFound();
            var employee = await this.unitOfWork.EmployeeRepository.Get(id);
            var MappedEmployee = this.mapper.Map<EmployeeViewModel>(employee);
            ViewBag.departments = await unitOfWork.DepartmentRepository.GetAll();
            
            if (employee == null)
                return NotFound();

            return View(MappedEmployee);
        }

        [HttpPost]
        public async Task<IActionResult> Update(int? id, EmployeeViewModel employeeViewModel)
        {

            if (id != employeeViewModel.Id)
                return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    employeeViewModel.ImageUrl = DocumentSettings.UploadFile(employeeViewModel.Image, "Images");

                    var MappedEmployee = this.mapper.Map<Employee>(employeeViewModel);
                    await this.unitOfWork.EmployeeRepository.Update(MappedEmployee);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    return View(employeeViewModel);
                }
            }
            return View(employeeViewModel);
        }
        #endregion

        #region Delete
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();
            var employee = await this.unitOfWork.EmployeeRepository.Get(id);

            if (employee == null)
                return NotFound();
            DocumentSettings.DeleteFile("Images",employee.ImageUrl);
            await this.unitOfWork.EmployeeRepository.Delete(employee);

            return RedirectToAction("Index");
        }


        #endregion




    }
}
