﻿using Microsoft.AspNetCore.Http;
using System;
using System.IO;
using System.Web;

namespace Ass2_MVC.Helper
{
    public static class DocumentSettings
    {
        public static string UploadFile(IFormFile file , string foldername)
        {
            //1- path allocation
            var FolderPath = Path.Combine(Directory.GetCurrentDirectory(),"wwwroot/Files",foldername);

            var fileName = $"{Guid.NewGuid()}{Path.GetFileName(file.FileName)}";

            var filePath = Path.Combine(FolderPath,fileName);

            using var fileStream = new FileStream(filePath, FileMode.Create);

            file.CopyTo(fileStream);

            return fileName;
        }

        public static void DeleteFile(string folderName, String FileName)
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Files",folderName, FileName);

            if (File.Exists(filePath))
            { File.Delete(filePath); }

        }
    }
}
