﻿using Ass.DAL.Entities;
using System.Net;
using System.Net.Mail;

namespace Ass2_MVC.Helper
{
    public static class EmailSettings
    {  
        public static void SendEmail(Email email)
        {
            var client = new SmtpClient("smtp.gmail.com", 587);
            client.EnableSsl = true;
            client.Credentials = new NetworkCredential("Your email", "key");

            client.Send("your email", email.To, email.Title, email.Body);
        }
    }
}
