﻿using Ass.BLL.Interfaces;
using Ass.DAL.Contexts;
using Ass.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ass.BLL.Repositories
{
    public class DepartmentRepository : GenericRepository<Department>,IDepartmentRepository
    {
        private readonly MVCAppDbContext Context;

        public DepartmentRepository(MVCAppDbContext context) :base(context) 
        {
            this.Context = context;
        }
    }
} 
