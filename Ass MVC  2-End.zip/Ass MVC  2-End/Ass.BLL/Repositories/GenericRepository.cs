﻿using Ass.BLL.Interfaces;
using Ass.DAL.Contexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Ass.BLL.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly MVCAppDbContext context;

        public GenericRepository(MVCAppDbContext context)
        {
            this.context = context;
        }
        public async Task<int> Add(T obj)
        {
            await context.Set<T>().AddAsync(obj);
            return await context.SaveChangesAsync();
        }

        public async Task<int> Delete(T obj)
        {
            context.Set<T>().Remove(obj);
            return await context.SaveChangesAsync();
        }

        public async Task<T> Get(int? id)

        => await context.Set<T>().FindAsync(id);

        public async Task<IEnumerable<T>> GetAll()

            => await context.Set<T>().ToListAsync();

        public async Task<int> Update(T obj)
        {
            context.Set<T>().Update(obj);
            return await context.SaveChangesAsync();
        }
    }
}
