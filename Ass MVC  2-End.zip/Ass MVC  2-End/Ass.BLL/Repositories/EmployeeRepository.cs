﻿using Ass.BLL.Interfaces;
using Ass.DAL.Contexts;
using Ass.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Ass.BLL.Repositories
{
    public class EmployeeRepository : GenericRepository<Employee>, IEmployeeRepository
    {
        private readonly MVCAppDbContext context;

        public EmployeeRepository(MVCAppDbContext context) : base(context)
        {
            this.context = context;
        }

        

        public async Task<string> GetDepartmentByEmployeeID(int? id)
        {
           var employee= await this.context.Employees.Where(d => d.Id == id).Include(e => e.Department).FirstOrDefaultAsync(); 
           var department = employee.Department;
            return department.Name;
        }

        public async Task<IEnumerable<Employee>> GetEmployeesByDepartmentName(string DeptName)
        {
            return await this.context.Employees.Where(x => x.Department.Name == DeptName).ToListAsync();
        }

        public async Task<IEnumerable<Employee>> Search(string Word)
        => await this.context.Employees.Where(x => x.Name.Contains(Word)).ToListAsync();    

       

        
    }
}
